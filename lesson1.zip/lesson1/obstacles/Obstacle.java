package lesson1.obstacles;

import lesson1.Player;

public abstract class Obstacle {
    public abstract void doIt(Player animal);
}
